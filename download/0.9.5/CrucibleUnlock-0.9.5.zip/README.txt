Crucible Unlock 0.9.5 - Steam public Build 22928553 only.
Place Mods/CrucibleUnlock.dll in the game installation directory.
Install MelonLoader 0.7.3 separately and set the CrucibleUnlock preferences.
See https://github.com/Venompool888/nrfw-second-crucible-unlock for full instructions.
